<?php
namespace Opencart\Admin\Controller\Extension\Paywise\Payment;
class Paywise extends \Opencart\System\Engine\Controller {
	public function index(): void {
		$this->load->language('extension/paywise/payment/paywise');

		$this->document->setTitle($this->language->get('heading_title'));

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment')
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/paywise/payment/paywise', 'user_token=' . $this->session->data['user_token'])
		];

		$data['save'] = $this->url->link('extension/paywise/payment/paywise.save', 'user_token=' . $this->session->data['user_token']);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment');

		$data['payment_paywise_order_status_id'] = $this->config->get('payment_paywise_order_status_id');

		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		$data['payment_paywise_geo_zone_id'] = $this->config->get('payment_paywise_geo_zone_id');

		$this->load->model('localisation/geo_zone');

		$data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();

		// $this->load->model('localisation/currency');

		// $data['currencies'] = $this->model_localisation_currency->getCurrencies();

		$data['currencies'] = array('USD' => 'USD', 'GHS' => 'GHS', 'EURO' => 'EURO', 'GBP' => 'GBP');

		$data['payment_paywise_title'] = $this->config->get('payment_paywise_title');
		$data['payment_paywise_description'] = $this->config->get('payment_paywise_description');
		$data['payment_paywise_terminalID'] = $this->config->get('payment_paywise_terminalID');
		$data['payment_paywise_password'] = $this->config->get('payment_paywise_password');
		$data['payment_paywise_currency'] = $this->config->get('payment_paywise_currency');
		$data['payment_paywise_address'] = $this->config->get('payment_paywise_address');
		$data['payment_paywise_billing'] = $this->config->get('payment_paywise_billing');
		$data['payment_paywise_color'] = $this->config->get('payment_paywise_color');
		$data['payment_paywise_bgcolor'] = $this->config->get('payment_paywise_bgcolor');
		$data['payment_paywise_txtcolor'] = $this->config->get('payment_paywise_txtcolor');
		$data['payment_paywise_api'] = $this->config->get('payment_paywise_api');
		$data['payment_paywise_cron'] = $this->config->get('payment_paywise_cron');
		$data['payment_paywise_geo_zone_id'] = $this->config->get('payment_paywise_geo_zone_id');
		$data['payment_paywise_status'] = $this->config->get('payment_paywise_status');
		$data['payment_paywise_sort_order'] = $this->config->get('payment_paywise_sort_order');
		$data['payment_paywise_filename'] = $this->config->get('payment_paywise_filename');

		$data['cron'] = HTTP_CATALOG. "index.php?route=extension/paywise/payment/paywise.cronjob";

		$data['user_token'] = $this->session->data['user_token'];
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/paywise/payment/paywise', $data));
	}

	public function save(): void {
		//echo "<pre>"; print_r($this->request->post);exit;
		$this->load->language('extension/paywise/payment/paywise');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/paywise/payment/paywise')) {
			$json['error']['warning'] = $this->language->get('error_permission');
		}

		if (!$json) {
			$this->load->model('setting/setting');

			$this->model_setting_setting->editSetting('payment_paywise', $this->request->post);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function upload(): void {
		$this->load->language('catalog/download');

		$json = [];

		// Check user has permission
		if (!$this->user->hasPermission('modify', 'catalog/download')) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (empty($this->request->files['file']['name']) || !is_file($this->request->files['file']['tmp_name'])) {
			$json['error'] = $this->language->get('error_upload');
		}

		if (!$json) {
			// Sanitize the filename
			$filename = basename(html_entity_decode($this->request->files['file']['name'], ENT_QUOTES, 'UTF-8'));

			// Validate the filename length
			if ((oc_strlen($filename) < 3) || (oc_strlen($filename) > 128)) {
				$json['error'] = $this->language->get('error_filename');
			}

			// Return any upload error
			if ($this->request->files['file']['error'] != UPLOAD_ERR_OK) {
				$json['error'] = $this->language->get('error_upload_' . $this->request->files['file']['error']);
			}
		}

		if (!$json) {
			move_uploaded_file($this->request->files['file']['tmp_name'], DIR_DOWNLOAD . $filename);

			$json['filename'] = $filename;

			$json['success'] = $this->language->get('text_upload');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}