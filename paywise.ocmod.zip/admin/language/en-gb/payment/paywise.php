<?php
// Heading
$_['heading_title']       					= 'Paywise'; 
$_['heading_title_main']  					= 'Paywise Checkout Integration';

$_['text_edit']          					= 'Edit Paywise';
$_['text_extension']                        = 'Extensions';
$_['text_success']          					= 'Edit Paywise';

// Entry
$_['entry_title']	 						= 'Title';
$_['entry_order_status']                    = 'Order Status';
$_['entry_description']                     = 'Description';
$_['entry_terminalID']                      = 'Terminal ID';
$_['entry_password']                        = 'Password';
$_['entry_address']                         = 'Address';
$_['entry_billing']                         = 'Dynamic Billing Descriptor';
$_['entry_currency']                        = 'Currency';
$_['entry_color']                           = 'Color';
$_['entry_bgcolor']                         = 'Background color';
$_['entry_txtcolor']                        = 'Button text color';
$_['entry_api']                             = 'API URL';
$_['entry_cron']                            = 'Cron URL';
$_['entry_upload']                          = 'File upload';
$_['entry_geo_zone']                        = 'Geo Zone';
$_['entry_status']                          = 'Status';
$_['entry_sort_order']                      = 'Sort order';

// Help
$_['help_title']		 					= 'This controls the title which the user sees during checkout.';
$_['help_description']		 				= 'This controls the description which the user sees during checkout.';
$_['help_terminalID']		 				= 'Terminal ID given by Paywise.';
$_['help_password']		 				    = 'This will be use for the payment description.';
$_['help_currency']		 				    = 'Select your currency. Default is : USD';
$_['help_address']		 				    = 'Click on check box for enable address param.';
$_['help_billing']		 				    = 'Click on check box for enable billing descriptor.';
$_['help_api']		 				        = 'TEST/ LIVE Environment URL.';
$_['help_cron']		 				        = 'To fetch record auto through cron task to run every hour.';
$_['help_upload']		 				    = 'Please upload your image';

// Success
$_['success_save']		 					= 'Success: You have modified Paywise!';
$_['success_send']		 					= 'Success: Your contact details have been successfully sent to paypal!';
$_['success_agree']		 					= 'Success: Deactivation was successful!';

// Error
$_['error_permission']	 					= 'Warning: You do not have permission to modify payment Paywise!';
$_['error_timeout'] 	  					= 'Sorry, Paywise is currently busy. Please try again later!';