<?php
namespace Opencart\Catalog\Controller\Extension\Paywise\Payment;

require_once(DIR_EXTENSION . "paywise/system/library/RSA.php");
require_once(DIR_EXTENSION . "paywise/system/library/BigInteger.php");
require_once(DIR_EXTENSION . "paywise/system/library/Hash.php");
require_once(DIR_EXTENSION . "paywise/system/library/Random.php");
require_once(DIR_EXTENSION . "paywise/system/library/RSA.php");

require_once(DIR_SYSTEM . "library/log.php");

use SimpleXMLElement;

class Paywise extends \Opencart\System\Engine\Controller {
	public function index(): string {
		$this->load->language('extension/paywise/payment/paywise');

		$data['language'] = $this->config->get('config_language');

        return $this->load->view('extension/paywise/payment/paywise', $data);
	}

	public function confirm(): void {
        
		$this->load->language('extension/paywise/payment/paywise');

		$json = [];

		if (!isset($this->session->data['order_id'])) {
			$json['error'] = $this->language->get('error_order');
		}

		if (!isset($this->session->data['payment_method']) || $this->session->data['payment_method']['code'] != 'paywise.paywise') {
			$json['error'] = $this->language->get('error_payment_method');
		}

		if (!$json) {
			$this->load->model('checkout/order');

			$this->model_checkout_order->addHistory($this->session->data['order_id'], $this->config->get('payment_paywise_order_status_id'));

            //Redirect url..
            $payWiseButtonUrl = $this->send_request_to_paywise_api($this->session->data['order_id']);
            $json['redirect'] = $payWiseButtonUrl;

			//$json['redirect'] = $this->url->link('checkout/success', 'language=' . $this->config->get('config_language'), true);
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

    //Sending Request to Paywise API...
    function send_request_to_paywise_api($order_id) {

        $order_info = $this->model_checkout_order->getOrder($order_id);

        $amount = number_format((float)$order_info['total'], 2, '.', '');
        
        $minor='';
        if(is_float((float)$amount) || is_double((double)$amount)) {
            $number = $amount * 100;				
            $zeros = 12 - strlen($number);
            $padding = '';
            for($i=0; $i<$zeros; $i++) {
                $padding .= '0';
            }
            $minor = $padding.$number;
        }
        
        if(strlen($amount)==12) {
            $minor = $amount;
        }

        $color = ltrim($this->config->get('payment_paywise_color'),"#");
        $bgcolor = ltrim($this->config->get('payment_paywise_bgcolor'), "#");
        $btntxtcolor = ltrim($this->config->get('payment_paywise_txtcolor'), "#");
        $trackId = 'ORDER-'.rand( 10000000000, 99999999999 );
        $udfs2 = rand(1000,9999);
        $udfs3 = rand(1000,9999);
        $udfs4 = rand(1000,9999);

        if($this->config->get('payment_paywise_address')){
            $address = 'false';
        }else{
            $address = 'true';  
        }

        if($this->config->get('payment_paywise_billing')){
            $billing_descriptor = 'true';
        }else{
            $billing_descriptor = 'false';
        }

        $comment = 'trackids:' . $trackId;

        $this->load->model('checkout/order');
        $this->model_checkout_order->addHistory($order_id, $this->config->get('payment_paywise_order_status_id'), $comment);

        //Redirect url..
        $redirect_data = 'terminalId='.$this->config->get('payment_paywise_terminalID').'&trackId='.$trackId.'&currency='.$this->config->get('payment_paywise_currency').'&amount='.$amount.'&disableAddressParam='.$address.'&enableDynamicBillingDescriptor='.$billing_descriptor.'&color='.$color.'&bgcolor='.$bgcolor.'&btntxtcolor='.$btntxtcolor.'&udfs1='.$order_id.'&udfs2='.$udfs2.'&udfs3='.$udfs3.'&udfs4='.$udfs4.'';

        //Generating 12 unique random transaction id...
        $transaction_id='';
        $allowed_characters = array(1,2,3,4,5,6,7,8,9,0); 
        for($i = 1;$i <= 12; $i++){ 
            $transaction_id .= $allowed_characters[rand(0, count($allowed_characters) - 1)]; 
            $this->session->data['paywise_wc_transaction_id'] = $transaction_id;
        } 

        //Hashing order details...
        $key_options = $transaction_id.$amount.$order_info['email'];
        $paywise_wc_hash_key = hash('sha512', $key_options);
        $this->session->data['paywise_wc_hash_key'] = $paywise_wc_hash_key;

        $public_key = file_get_contents(DIR_DOWNLOAD . $this->config->get('payment_paywise_filename'));
        $ciphertext = $this->rsa_encrypt($redirect_data, $public_key);
        $epay = urlencode($ciphertext);
        $payWiseButtonUrl = $this->config->get('payment_paywise_api') . '?epay='.$epay;
        return $payWiseButtonUrl;
    }

    function rsa_encrypt($string, $public_key){
        $cipher = new \Crypt_RSA();
        $cipher->loadKey($public_key);
        $cipher->setEncryptionMode(CRYPT_RSA_ENCRYPTION_PKCS1);
        return base64_encode($cipher->encrypt($string));
    }

    public function callback(){
        if (isset($_REQUEST["udfs1"]) && $_REQUEST["udfs1"] && isset($_REQUEST["transid"]) && $_REQUEST["transid"] ) {
            $this->check_paywise_response();
        }
    }

    //Getting Paywise Api response...      
    function check_paywise_response() {
    
        $this->load->model('checkout/order');
        $order_id = isset($_REQUEST["udfs1"]) ? (int)$_REQUEST["udfs1"] : "";
        if(empty($order_id)){
            $this->session->data['error'] = 'Something went wrong, Please try again later.';
            $this->response->redirect($this->url->link('checkout/cart', 'language=' . $this->config->get('config_language')));
            exit();
        }

        $code = isset($_REQUEST["responsecodes"]) ? $_REQUEST["responsecodes"] : "";
        $status = isset($_REQUEST["status"]) ? $_REQUEST["status"] : "";
        $transaction_id = isset($_REQUEST["transid"]) ? $_REQUEST["transid"] : "";
        $reason = isset($_REQUEST["reason"]) ? $_REQUEST["reason"] : "";

        $wc_order_id = (int)$this->session->data['order_id'];

        if(empty($wc_order_id)){
            $this->session->data['error'] = 'Something went wrong, Please try again later.';
            $this->response->redirect($this->url->link('checkout/cart', 'language=' . $this->config->get('config_language')));
            exit();
        }

        $order = $this->model_checkout_order->getOrder($wc_order_id);

        $wc_transaction_id = $this->session->data['paywise_wc_transaction_id'];
        $paywise_wc_hash_key = $this->session->data['paywise_wc_hash_key'];

        if(empty($paywise_wc_hash_key) || $paywise_wc_hash_key == null || $paywise_wc_hash_key == ""){
            $message_type = "error"; 
	        $this->log('Checking Response: Invalid hash key or empty');
            die("<h2 style=color:red>Ooups ! something went wrong </h2>");
        }
            
        if($order_id != $wc_order_id){
            $this->log('Error: Order ID different from session Order ID');
            $this->session->data['error'] = 'Error: Order ID different from session Order ID';
            $message_type = "error"; 
            $message = "Code 0001 : Data has been tampered .  Order ID is ".$wc_order_id."";
            $this->model_checkout_order->addHistory($order_id, 7, $message);
            $this->response->redirect($this->url->link('checkout/cart', 'language=' . $this->config->get('config_language')));
            exit();
        }

        if($_GET['transid'] == ''){
            $this->write( 'Error: Order ID different from session Order ID' );
            $this->session->data['error'] = 'Error: Order ID different from session Order ID';
            $message_type = "error"; 
            $message = "Transaction ID should not be empty. Order ID is ".$wc_order_id."";
            $this->model_checkout_order->addHistory($order_id, 7, $message);
            $this->response->redirect($this->url->link('checkout/checkout', 'language=' . $this->config->get('config_language')));
            exit();          
        }

        if($transaction_id == $wc_transaction_id){
            $this->write( 'Error: Transaction ID different from session Transaction ID');
            $this->session->data['error'] = 'Error: Transaction ID different from session Transaction ID';
            $message_type = "error";
            $message = "Code 0002: Data has been tampered . Order ID is ".$wc_order_id."";
            $this->model_checkout_order->addHistory($order_id, 7, $message);
            $this->response->redirect($this->url->link('checkout/checkout', 'language=' . $this->config->get('config_language')));
            exit();
        }
          
        if (!empty($order_id) || $order_id !=="" || $order_id !== null  && !empty($code) || $code !=="" || $code !== null && !empty($transaction_id) || $transaction_id !=="" || $transaction_id !== null) {
            try {                                             
                if($code =="000"){
                    $message_type = "success";

                    $message = "Thank you for shopping with us. 
                        Your transaction was successful, payment has been received. 
                        You order is currently being processed. 
                        Your Order ID is ".$wc_order_id."";

                    $this->session->data['success'] = $message;
                    
                    $comment = 'Paywise status code : '.$code.'<br/>Transaction ID  ' . $transaction_id.'<br /> Reason: '.$reason.'';
                    $this->model_checkout_order->addHistory($order_id, 5, $comment);
                    
                    unset($this->session->data['paywise_wc_hash_key']);
                    unset($this->session->data['paywise_wc_order_id']);
                    unset($this->session->data['paywise_wc_transaction_id']);

                    $this->response->redirect( $this->url->link('checkout/success', 'language=' . $this->config->get('config_language')));
                    exit();

                }else{
                    
                    $message = "Error: Thank you for shopping with us. However, the transaction has been declined.";
                    $message_type = "error";

                    $this->session->data['error'] = $message;

                    $comment = 'Paywise status code : '.$code.'<br/>Transaction ID  ' . $transaction_id.'<br /> Reason: '.$reason.'';
                    //Failed order
                    $this->model_checkout_order->addHistory($order_id, 10, $comment);

                    //$this->cart->clear();

                    unset($this->session->data['paywise_wc_hash_key']);
                    unset($this->session->data['paywise_wc_order_id']);
                    unset($this->session->data['paywise_wc_transaction_id']);
                    
                    $this->response->redirect($this->url->link('checkout/cart', 'language=' . $this->config->get('config_language')));
                    exit();
                } 
            }

            catch (Exception $e) {
                $this->log('Error: Payment Exception '.$e->getMessage(), 'error' );
                $this->response->redirect($this->url->link('checkout/cart', 'language=' . $this->config->get('config_language')));
                exit();
            }
        }
    }

	function log($message) {
        $log = new \Opencart\System\Library\Log('paywise.log');
		$log->write(date('Y-m-d H:i:s') . ' - ' . print_r($message, true) . "\n", FILE_APPEND);
	}

    public function cronjob(){

        $this->load->model('extension/paywise/payment/paywise');
		
		$customer_orders = $this->model_extension_paywise_payment_paywise->getOrders(0, 5);

        if($customer_orders){

            // Iterating through each Order with pending status
            foreach ( $customer_orders as $order ) {
                $order_id = $order['order_id'];
                $order_history_info = $this->model_extension_paywise_payment_paywise->getOrderHistory($order_id);
                //echo "<pre>"; print_r($order_history_info);exit;
                if( $order_history_info ) {
                    
                    $comments = explode(":", $order_history_info['comment']);
                    $trackid = isset($comments[1]) ? trim($comments[1]) : "";
                    $action = 15;
                    $terminal_id = $this->config->get('payment_paywise_terminalID');
                    $password = $this->config->get('payment_paywise_password');

                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $this->config->get('payment_paywise_cron'),
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => "",
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 30,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => "<request>\n<terminalid>".$terminal_id."</terminalid>\n<password>".$password."</password>\n<action>".$action."</action>\n<trackid>".$trackid."</trackid>\n<udf1>".$order_id."</udf1>\n</request>",
                        CURLOPT_HTTPHEADER => array(
                            "cache-control: no-cache",
                            "content-type: application/xml",                
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    curl_close($curl);
                    if( $response ){
                        $this->load->model('checkout/order');
                        //$this->log('Error: Payment Exception '.$err->getMessage(), 'error' );
                        $xmldata = new SimpleXMLElement($response);
                        $json_string = json_encode($xmldata);    
                        $result_array = json_decode($json_string, TRUE);
                        //echo "<pre>"; print_r($result_array);exit;

                        if($result_array['responsecode'] == '000'){
                            $message_type = "success";

                            $message = "Thank you for shopping with us. 
                                Your transaction was successful, payment has been received. 
                                You order is currently being processed. 
                                Your Order ID is ".$order_id."";

                            $this->session->data['success'] = $message;

                            $code = isset($result_array["responsecode"]) ? $result_array["responsecode"] : "";
                            $transaction_id = isset($result_array["transid"]) ? $result_array["transid"] : "";
                            $reason = isset($result_array["udf5"]) ? $result_array["udf5"] : "";
                            
                            $comment = 'Paywise status code : '.$code.'<br/>Transaction ID  ' . $transaction_id .'<br /> Reason: '.$reason.'';
                            $this->model_checkout_order->addHistory($order_id, 5, $comment);
                            
                            unset($this->session->data['paywise_wc_hash_key']);
                            unset($this->session->data['paywise_wc_order_id']);
                            unset($this->session->data['paywise_wc_transaction_id']);

                            $this->response->redirect( $this->url->link('checkout/success', 'language=' . $this->config->get('config_language')));
                            exit();
                        }else {
                            if(isset($trackid) && $trackid){
                                $comment = 'Paywise status code : '.$code.'<br/>Transaction ID  ' . $transaction_id.'<br /> Reason: '.$reason.'';
                                //Failed order
                                $this->model_checkout_order->addHistory($order_id, 10, $comment);
                            }   
                        }
                    }else{
                        if(isset($trackid) && $trackid){
                            $comment = 'Paywise status code : '.$code.'<br/>Transaction ID  ' . $transaction_id.'<br /> Reason: '.$reason.'';
                            //Failed order
                            $this->model_checkout_order->addHistory($order_id, 10, $comment);
                            exit();
                        }
                    }
                }
            }
        }
    }
}