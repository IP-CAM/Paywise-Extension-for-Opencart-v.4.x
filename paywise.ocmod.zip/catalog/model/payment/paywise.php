<?php
namespace Opencart\Catalog\Model\Extension\Paywise\Payment;
class Paywise extends \Opencart\System\Engine\Model {
	public function getMethods(array $address = []): array {
		$this->load->language('extension/paywise/payment/paywise');

		if ($this->cart->hasSubscription()) {
			$status = false;
		} elseif (!$this->config->get('config_checkout_payment_address')) {
			$status = true;
		} elseif (!$this->config->get('payment_paywise_geo_zone_id')) {
			$status = true;
		} else {
			$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "zone_to_geo_zone` WHERE `geo_zone_id` = '" . (int)$this->config->get('payment_paywise_geo_zone_id') . "' AND `country_id` = '" . (int)$address['country_id'] . "' AND (`zone_id` = '" . (int)$address['zone_id'] . "' OR `zone_id` = '0')");

			if ($query->num_rows) {
				$status = true;
			} else {
				$status = false;
			}
		}

		$method_data = [];

		if ($status) {
			$option_data['paywise'] = [
				'code' => 'paywise.paywise',
				'name' => !empty($this->config->get('payment_paywise_title')) ? $this->config->get('payment_paywise_title') : $this->language->get('heading_title')
			];

			$method_data = [
				'code'   => 'paywise',
				'name'       => !empty($this->config->get('payment_paywise_title')) ? $this->config->get('payment_paywise_title') : $this->language->get('heading_title'),
				'option'     => $option_data,
				'sort_order' => $this->config->get('payment_paywise_sort_order')
			];
		}

		return $method_data;
	}

	
	public function getOrders(int $start = 0, int $limit = 20): array {
		if ($start < 0) {
			$start = 0;
		}

		if ($limit < 1) {
			$limit = 1;
		}

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "order` WHERE `customer_id` = '" . (int)$this->customer->getId() . "' AND `store_id` = '" . (int)$this->config->get('config_store_id') . "' AND payment_method LIKE '%paywise.paywise%' AND order_status_id != 5 AND order_status_id != 10  ORDER BY `order_id` DESC LIMIT " . (int)$start . "," . (int)$limit);

		return $query->rows;
	}

	public function getOrderHistory(int $order_id): array {
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "order_history` WHERE `order_id` = '" . (int)$order_id . "' AND comment LIKE '%trackids%' ORDER BY `order_history_id` DESC LIMIT 1");
		if($query->num_rows){
			return $query->row;
		}else{
			return array();
		}
			
	}
}
